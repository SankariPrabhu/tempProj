package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import driver.Action;

public class LoginPage extends Action{
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	public void enterUserName(String username) {
		enterText(driver.findElement(By.cssSelector("input[class='_2zrpKA']")), username);
	}
	
	public void enterPassword(String pwd) {
		enterText(driver.findElement(By.cssSelector("input[type='password']")), pwd);
	}
	
	public HomePage clickLoginButton() {
		clickElement(driver.findElement(By.cssSelector("button[class='_3zLR9i _1LctnI _36SmAs']")));
		return new HomePage(driver);
	}
}
