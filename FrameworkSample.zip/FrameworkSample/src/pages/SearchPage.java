package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage {
	WebDriver driver;
	public ProductPage productPage;
	

	public SearchPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public ProductPage results(){
		driver.findElement(By.cssSelector("a[title='LeEco Le 2 (Rose Gold, 32 GB)']")).click();
		return new ProductPage(driver);
	}
}
