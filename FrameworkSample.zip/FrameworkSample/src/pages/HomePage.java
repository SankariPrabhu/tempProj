package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import driver.Action;


public class HomePage  extends Action{

	WebDriver driver;



	public HomePage homepage;
	public SearchPage searchPage;
	
	
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}



	public SearchPage enterSearch(){
		enterText(driver.findElement(By.cssSelector("input[type='text']")), "mobile");
		//driver.findElement(By.cssSelector("input[type='text']")).sendKeys("mobile");
		//driver.findElement(By.cssSelector("button[type='submit']")).click();
		clickElement(driver.findElement(By.cssSelector("button[type='submit']")));
		return new SearchPage(driver);
	}
	
	public LoginPage clickLogin() {
		clickElement(driver.findElement(By.linkText("Log In")));
		return new LoginPage(driver);
	}
	
	

}
