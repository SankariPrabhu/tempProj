package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import driver.Action;

public class ProductPage extends Action{
	WebDriver driver;
	
	String image = "xpath=//div[@data-imageid='IMAEJGUG79UFG664']";
	
	
	public ProductPage(WebDriver driver) {
		this.driver = driver;
	}

	public ProductPage verifyTitle(){
		String title = driver.findElement(By.cssSelector("h1[class='title']")).getText();
		System.out.println(title);
		return this;
	}
	
	public void mouseOverAndClickImage() {
		mouseOver(driver, getElement(driver, image));
		clickElement(getElement(driver, image));
	}
	
	public LoginPage clickLogin() {
		clickElement(driver.findElement(By.linkText("Log in")));
		return new LoginPage(driver);
	}
	
	

	
}
