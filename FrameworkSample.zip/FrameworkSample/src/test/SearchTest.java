package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import data.Testdata;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductPage;
import pages.SearchPage;
import driver.Driver;

public class SearchTest extends Driver{

	public HomePage homepage;
	public SearchPage searchPage;
	public ProductPage productPage;
	public LoginPage loginPage;
	
	@Test
	public void searchflip(){
		System.out.println(Testdata.getValueFromExcel("UserName"));
		HomePage homePage = new HomePage(driver);
		
		loginPage = homePage.clickLogin();
		loginPage.enterUserName(Testdata.getValueFromExcel("UserName"));
		loginPage.enterPassword(Testdata.getValueFromExcel("Password"));
		homePage = loginPage.clickLoginButton();
		/*loginPage.enterEmail(TestData.getValueFromExcel("UserName"));
		loginPage.enterPwd(TestData.getValueFromExcel("Password"));*/
		searchPage = homePage.enterSearch();
		//SearchPage searchPage1 = new SearchPage(driver);
		productPage = searchPage.results();
		//ProductPage productPage1 = new ProductPage(driver);
		productPage.verifyTitle();
		productPage.mouseOverAndClickImage();
		loginPage = productPage.clickLogin();
		
		
	}
}
