package data;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Testdata {
	static Properties dataProp = new Properties();
	public static void readData(){
	 
		 try{
			 dataProp.load(new FileInputStream("data.properties"));
		 }
		 catch(Exception e){
			 
		 }
	}
	public static String getData(String property){
		return dataProp.getProperty(property);
	}
	//https://www.apache.org/dyn/closer.lua/poi/dev/bin/poi-bin-3.15-beta2-20160702.zip
	public static String getValueFromExcel(String key) {
		try {
			XSSFWorkbook book = new XSSFWorkbook(new FileInputStream(new File("Input.xlsx")));
			XSSFSheet sheet = book.getSheetAt(0);
			System.out.println(sheet.getPhysicalNumberOfRows());
			int j = 1;
			//System.out.println(sheet.getPhysicalNumberOfRows());
			for(int i=0; i< sheet.getPhysicalNumberOfRows()  ; i++) {
				//System.out.println(sheet.getRow(0).getCell(i).getStringCellValue());
				
				/*System.out.println(sheet.getRow(0).getCell(i).getStringCellValue());
				System.out.println(sheet.getRow(1).getCell(i).getStringCellValue());*/
				if(sheet.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(key)) {
					XSSFCell cell = sheet.getRow(j).getCell(i);
					if(cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
						//System.out.println(cell.getStringCellValue());
						return cell.getStringCellValue();
					} else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
						//System.out.println(cell.getRawValue().toString());
						return cell.getRawValue();
					}
				}
			}
		} catch (Exception E) {
			E.printStackTrace();
		}
		
		return key;
		
	}
	
}
