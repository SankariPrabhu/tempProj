package data;

public class TestExcel {
	public static void main(String a[]) {
		Testdata.getValueFromExcel("UserName");
	}
}
