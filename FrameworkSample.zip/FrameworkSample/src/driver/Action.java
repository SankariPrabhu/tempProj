package driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Action {
	protected void clickElement(WebElement element) {
		element.click();
	}
	
	protected void enterText(WebElement element, String text) {
		element.sendKeys(text);
		
	}
	
	protected void mouseOver(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
	}
	
	protected WebElement getElement(WebDriver driver, String locator) {
		WebElement ele =  null;
		if(locator.startsWith("xpath=")) {
			String[] loc =  locator.split("xpath=");
			ele = driver.findElement(By.xpath(loc[1]));	
		}
		return ele;
	}
}
