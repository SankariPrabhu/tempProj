package driver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import data.Testdata;

public class Driver {
	
	protected WebDriver driver;
	
	

	public void loadBrowser(String browser){
		
		if(browser.equalsIgnoreCase("firefox")){
			driver = new FirefoxDriver();
			
		}
		if(browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver","C:\\Automation\\Browsers\\Chrome\\chromedriver.exe");
			driver = new ChromeDriver();
			
		}
		if(browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver","");
			driver = new InternetExplorerDriver();
			
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@BeforeClass
	public void loadData(){
		Testdata.readData();
	}
	
	@BeforeMethod
	public void loadBrowser(){
		loadBrowser(Testdata.getData("browser"));
		driver.get(Testdata.getData("url"));
	}
	
	/*@AfterClass
	public void tearDown() {
		driver.quit();
	}*/

}
