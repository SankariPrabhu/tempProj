package javaAssignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapExample {

public static void main(String[] args) {
HashMap<Integer,String> hm=new HashMap<Integer,String>();
hm.put(1, "UFT");
hm.put(2, "Selenium IDE");
hm.put(3, "Selenium RC");
hm.put(4, "Selenium WebDriver");
hm.put(5, "Selenium Grid");
Set hmset=hm.entrySet();
Iterator itr=hmset.iterator();
while(itr.hasNext()){
Map.Entry hmMap=(Entry) itr.next();
System.out.println("Key:"+hmMap.getKey());
System.out.println("Value of an key:"+hmMap.getValue());
}
System.out.println("HasMap using Entryset method:"+hm.entrySet());
 
System.out.println("Is HashMap empty?"+hm.isEmpty());
System.out.println("Size of HashMap:"+hm.size());
System.out.println("Item present in second place:"+hm.get(2));
System.out.println("Remove one item from hashMap");
hm.remove(5);
System.out.println("Size of HashMap after removing method:"+hm.size());
}

}
