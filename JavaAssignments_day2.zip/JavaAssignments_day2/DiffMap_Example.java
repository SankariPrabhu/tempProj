package javaAssignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.TreeMap;

public class DiffMap_Example {

public static void main(String[] args) {
HashMap<Integer,String> hm=new HashMap<Integer,String>();
LinkedHashMap<Integer,String> lhm=new LinkedHashMap<Integer,String>();
TreeMap<Integer,String> thm=new TreeMap<Integer,String>();
hm.put(5, "UFT");
hm.put(6, "Selenium IDE");
Set hmset=hm.entrySet();
Iterator itr=hmset.iterator();
while(itr.hasNext()){
Map.Entry hmMap=(Entry) itr.next();
System.out.println("Key:"+hmMap.getKey());
System.out.println("Value of an key:"+hmMap.getValue());
}
System.out.println("Size of HashMap:"+hm.size());
lhm.put(3, "Selenium RC");
lhm.put(4, "Selenium WebDriver");
Set lhmset=lhm.entrySet();
Iterator itr1=lhmset.iterator();
while(itr1.hasNext()){
Map.Entry lhmMap=(Entry) itr1.next();
System.out.println("Key:"+lhmMap.getKey());
System.out.println("Value of an key:"+lhmMap.getValue());
}
System.out.println("Size of LinkedHashMap:"+lhm.size());
thm.put(8, "Selenium Grid");
thm.putAll(lhm);
Set thmset=thm.entrySet();
Iterator itr2=thmset.iterator();
while(itr2.hasNext()){
Map.Entry thmMap=(Entry) itr2.next();
System.out.println("Key:"+thmMap.getKey());
System.out.println("Value of an key:"+thmMap.getValue());
}
System.out.println("Size of TreeHashMap:"+thm.size());

}

}

