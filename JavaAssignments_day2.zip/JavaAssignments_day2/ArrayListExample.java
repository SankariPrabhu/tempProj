package javaAssignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListExample {

public static void main(String[] args) {
List<String> alist=new ArrayList();
alist.add("UFT");
alist.add("Selenium IDE");
alist.add("Selenium RC");
alist.add("Selenium Webdriver");
alist.add("Selenium Grid");
System.out.println("Size of list:"+alist.size());
for(String arrstr:alist){
if(arrstr.contains("UFT")){
System.out.println("String :"+arrstr+" is present");
break;
}
}
System.out.println("Strings available in List");
Iterator <String> Itr=alist.iterator();
while(Itr.hasNext()){
System.out.println(Itr.next());
}
alist.remove("Selenium IDE");
System.out.println("Size of list after removing one string:"+alist.size());
}

}
