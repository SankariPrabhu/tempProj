package javaAssignment;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Demosite_ArrayList {

public static void main(String[] args) {
WebDriver driver=new FirefoxDriver();
driver.get("http://demoqa.com/");
driver.manage().window().maximize();
List<WebElement> interactionlist=driver.findElements(By.cssSelector("#menu-interactions>li"));
System.out.println("No of items in Interaction tab:"+interactionlist.size());
for(int i=0;i<=interactionlist.size()-1;i++){
if(interactionlist.get(i).getText().contains("Resizable")){
interactionlist.get(i).click();
System.out.println("Resizable tab is clicked successfully...");
break;
}
}
driver.close();
}

}
