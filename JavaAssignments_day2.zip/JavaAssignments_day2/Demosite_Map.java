package javaAssignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class Demosite_Map {
public static void main(String args[]) throws InterruptedException{
WebDriver driver=new FirefoxDriver();
driver.get("http://demoqa.com/");
driver.manage().window().maximize();
List<WebElement> widgetlist=driver.findElements(By.cssSelector("#menu-widget>li"));
Map<String,String> hm=new HashMap<String,String>();
String ElemText = null;
String ElemURL = null;
int j=0;
for(int i=1;i<=widgetlist.size()-4;i++){
ElemURL=driver.findElement(By.xpath("//ul[@id='menu-widget']/li["+i+"]/a")).getAttribute("href");
ElemText=driver.findElement(By.xpath("//ul[@id='menu-widget']/li["+i+"]")).getText();
hm.put(ElemText, ElemURL);
}
System.out.println("Key and URL value of Map items are:"+hm);
for(String key:hm.keySet()){
String hmurl=hm.get(key);
System.out.println(hm.get(key));
driver.findElement(By.linkText(key)).click();
Thread.sleep(2000);
String url=driver.getCurrentUrl();
Assert.assertEquals(hmurl, url);
j++;
}
driver.close();
}

}
