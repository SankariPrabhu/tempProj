package javaAssignment;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class PriorityQueueExample {

public static void main(String[] args) {
PriorityQueue<String> pqlist=new PriorityQueue<String>();
Scanner scan=new Scanner(System.in);
for(int i=0;i<=5;i++){
System.out.println("Enter values to store:");
pqlist.add(scan.next());
}
System.out.println(pqlist);
System.out.println("Size of queue:"+pqlist.size());
System.out.println("Items stored in queue:");
Iterator <String> Itr=pqlist.iterator();
while(Itr.hasNext()){
System.out.println(Itr.next());
}
System.out.println("Queue using Element method:"+pqlist.element());
System.out.println("Queue using Peek method:"+pqlist.peek());
System.out.println("Is queue empty?:"+pqlist.isEmpty());
System.out.println("Queue using remove method:"+pqlist.remove());
System.out.println("Queue using Poll method:"+pqlist.poll());
System.out.println("Size of Queue after using removing and polling method:"+pqlist.size());
System.out.println("Queue using clear method");
pqlist.clear();
System.out.println("is Queue empty after clear method:"+pqlist.isEmpty());
}
}
