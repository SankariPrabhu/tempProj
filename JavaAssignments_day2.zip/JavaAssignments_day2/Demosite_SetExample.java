package javaAssignment;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Demosite_SetExample {

public static void main(String[] args) {
WebDriver driver=new FirefoxDriver();
driver.get("http://demoqa.com/");
driver.manage().window().maximize();

List<WebElement> Registrationlist=driver.findElements(By.cssSelector("#menu-registration>li"));
List<WebElement> interactionlist=driver.findElements(By.cssSelector("#menu-interactions>li"));
List<WebElement> widgetlist=driver.findElements(By.cssSelector("#menu-widget>li"));
List<WebElement> Windowlist=driver.findElements(By.cssSelector("#menu-frames-and-windows>li"));
Set<String> hs= new HashSet<String>();
Set<String> lhs= new LinkedHashSet<String>();
Set<String> ths= new TreeSet<String>();
for(WebElement Reg:Registrationlist){
hs.add(Reg.getText());
}
System.out.println("Registration Tab contents:"+hs);
for(WebElement inter:interactionlist){
lhs.add(inter.getText());
}
System.out.println("Interaction Tab contents:"+lhs);
for(WebElement widget:widgetlist){
ths.add(widget.getText());
}
System.out.println("Widget Tab contents:"+ths);

for(WebElement wind:Windowlist){
ths.add(wind.getText());
}
System.out.println("Frame and Window Tab contents:"+ths);
hs.addAll(lhs);
hs.addAll(ths);
System.out.println("After adding allset values:"+hs);
System.out.println("Size of set after adding all values into single Set:"+hs.size());
driver.close();
}

}
