package javaAssignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class DiffList_Example {

public static void main(String[] args) {
List<String> alist=new ArrayList();
List<String> llist=new LinkedList<String>();
alist.add("UFT");
alist.add("Selenium IDE");
alist.add("Selenium RC");
System.out.println("Size of Array list:"+alist.size());
System.out.println("Strings available in Array List");
Iterator <String> Itr=alist.iterator();
while(Itr.hasNext()){
System.out.println(Itr.next());
}
llist.add("Selenium Webdriver");
llist.add("Selenium Grid");
System.out.println("Size of Linked list:"+llist.size());
System.out.println("Strings available in Linked List");
Iterator <String> Itr1=llist.iterator();
while(Itr1.hasNext()){
System.out.println(Itr1.next());
}
}

}
