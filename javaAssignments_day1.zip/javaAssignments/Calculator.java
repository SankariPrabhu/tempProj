package javaAssignments;

/*
 *Assignment 3.
Write a program:
Create Super Class Calculator
Create instance variable  x,y as integer
Create method Add to add the sum
Create method Mult to multiply the x and y
Create method Substarct to substract x and y
And display all outcomes as a output
 */
public class Calculator {
	int x,y;
	
	void Add(int x,int y){
		System.out.println("Add Method: "+(x+y));
	}
	
	void Subtract(int x,int y){
		System.out.println("Subtract Method: "+(x-y));
	}
	
	void Multiply(int x,int y){
		System.out.println("Multiply Method: "+(x*y));
	}

	public static void main(String[] args) {
		Calculator calc=new Calculator();
		calc.Add(10,5);
		calc.Subtract(10, 5);
		calc.Multiply(10, 5);
		

	}

}
