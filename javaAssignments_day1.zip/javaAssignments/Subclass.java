package javaAssignments;
/**
 * Assignment 2.
Write a program:
Create super  Class SuperClass as Abstract
Create Abstract Method To display �This is Abstract class Example�
Create subclass Childclass
Provide implementation part for super class Abstract method and display the result.
 * 
 *
 */
public class Subclass extends Superclass {

	void display() {
		System.out.println("This is an Example of Abstract class");
	}
	
	public static void main(String[] args) {
		Subclass sc = new Subclass();
		sc.display();
		
	}
}
