package javaAssignments;
/**
 *  Assignment 1:
 
Write a program:
1.Create Class EmployeeDeatils
2.Create constructor to insert record:(Your id and your name)
3.Create method Display() to display the record
By using a class concept.
 *
 */
public class EmployeeDetails {
	int id;
	String name;
	
	public EmployeeDetails(int id, String name){
		this.id =id;
		this.name=name;		
	}
	
	public void display(){
		System.out.println("Id: "+id);
		System.out.println("Name: "+name);
	}
	
	public static void main(String[] args) {
		EmployeeDetails Ed=new EmployeeDetails(244306,"Sankari");
		EmployeeDetails Ed1=new EmployeeDetails(25213,"Prabhu");
		Ed.display();
		Ed1.display();
	}

}
