package javaAssignments;
/**
 * 
 * Assignment4
 * http://www.guideforschool.com/444401-question-11-inheritance-isc-2011-theory-paper-solved/
 *
 */
public class Record {
	String name[]=new String[6];
	int[] rank=new int[6];
	
	Record(){
		 
	}
	 void readvalues(){
		 
	 }
	 void display(){
		 
	 }

}
