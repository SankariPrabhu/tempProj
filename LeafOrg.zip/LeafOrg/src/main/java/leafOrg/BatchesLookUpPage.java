package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class BatchesLookUpPage extends LeafOrgWrappers{
	public BatchesLookUpPage(AndroidDriver<?> driver, ExtentTest test) {

		this.driver = driver;
		this.test = test;
	}

	public BatchesLookUpPage selectAppiumMayBatch(){
		clickByXpath(prop.getProperty("BatchesLookup.May2017Text.Xpath"));
		return this;
	}
	
	public BatchesLookUpPage verifyErrorPopUpMessage(){
		verifyContentDescIsDisplayed(prop.getProperty("BatchesLookup.ErrorPopupText.Xpath"));
		return this;
	} 
	
	public BatchesPage clickOkErrorPopup(){
		verifyContentDescIsDisplayed(prop.getProperty("Batches.OkButtonErrorPopup"));
		return new BatchesPage(driver,test);
	} 

	public BatchesLookUpPage searchBatchInLookup(String text){
		enterTextByXpath(prop.getProperty("BatchesLookup.SearchBox.Xpath"),text);
		return this;
	}
	
	public BatchesPage clickOkButton(){
		clickByXpath(prop.getProperty("BatchesLookup.OkButton.Xpath"));
		return new BatchesPage(driver,test);
	} 
	
	
	


}