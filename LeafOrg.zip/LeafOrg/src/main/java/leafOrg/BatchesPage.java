package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class BatchesPage extends LeafOrgWrappers{
	public BatchesPage(AndroidDriver<?> driver, ExtentTest test) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		this.test = test;
	}
	
	
	public SettingsPage clickBackButton( ){
		clickByXpath(prop.getProperty("Batches.BackButton.Xpath"));
		return new SettingsPage(driver,test);	
	}
	
	public BatchesLookUpPage clickAddButton(){
		clickByXpath(prop.getProperty("Batches.Add.Xpath"));
		return new BatchesLookUpPage(driver,test);
	}
	
	public BatchesPage VerifyNoBatchesText(){
		verifyContentDescIsDisplayed(prop.getProperty("Batches.VerifyNoBatchesText"));
		return new BatchesPage(driver,test);
	}
	
	

	
}