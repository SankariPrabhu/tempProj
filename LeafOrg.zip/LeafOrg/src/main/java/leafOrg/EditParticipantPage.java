package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class EditParticipantPage extends LeafOrgWrappers{
	public EditParticipantPage(AndroidDriver<?> driver, ExtentTest test) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		this.test = test;
	}

	public EditParticipantPage editParticipantId(String participantId){
		clickByXpath(prop.getProperty("EditPage.ParticipantID.Xpath"));
		enterTextByXpath(prop.getProperty("EditPage.ParticipantID.Xpath"), participantId);	
		return this;
	}

	public EditParticipantPage clickParticipantDate(){
		clickByXpath(prop.getProperty("EditPage.ParticipantDate.Xpath"));
		switchview();
		return this;
	}

	public EditParticipantPage setParticipantDate(){
		clickByID(prop.getProperty("EditPage.Participantdateset.Id"));
		return this;
	}

	public EditParticipantPage editMentorName(String mentorName){
		switchWebview();
		enterTextByXpath(prop.getProperty("EditPage.Mentorname.Xpath"),mentorName );	
		return this;
	}

	public EditParticipantPage editUrl(String url){
		enterTextByXpath(prop.getProperty("EditPage.Url.Xpath"), url);	
		return this;
	}

	public EditParticipantPage editDriverLicense(String drivingLicenseId){
		enterTextByXpath(prop.getProperty("EditPage.DriverLicense.Xpath"), drivingLicenseId);	
		return this;
	}

	public EditParticipantPage clickLicenseExpDate(){
		clickByXpath(prop.getProperty("EditPage.Licexp.Xpath"));
		switchview();
		return this;
	}

	public EditParticipantPage setLicenseExpDate(){
		clickByID(prop.getProperty("EditPage.Licexpset.Id"));
		switchview();
		return this;
	}

	public EditParticipantPage clickSaveChanges(){
		clickByXpath(prop.getProperty("EditPage.Save.Xpath"));	
		return this;
	}

	public EditParticipantPage verifyTextMsg(String text) throws InterruptedException{
		verifyAttributeTextByXPath(prop.getProperty("EditPage.verifyinfomsg.Xpath"), text);
		return this;
	}

	/*public EditParticipantPage verifyTextMsg1(String xpath, String text1){
		enterTextByXpath(prop.getProperty("EditPage.verifyinfomsg1.Xpath"), text1);	
		return this;
	}*/

	public EditParticipantPage clickAlertMsg(){
		clickByXpath(prop.getProperty("EditPage.Alertmsgclick.Xpath"));	
		return this;
	}

	public SettingsPage clickBack(){
		clickByXpath(prop.getProperty("EditPage.Back.Xpath"));	
		return new SettingsPage(driver, test);
	}




}