package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class ChangePasswordPage extends LeafOrgWrappers{
	public ChangePasswordPage(AndroidDriver<?> driver, ExtentTest test) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		this.test = test;
	}

	public ChangePasswordPage enterCurrentPassword(String argOldPassword){
		enterTextByXpath(prop.getProperty("ChangePasswordPage.CurrentPassword.Xpath"), argOldPassword);
		return this;
	}

	public ChangePasswordPage enterNewPassword(String argNewPassword){
		enterTextByXpath(prop.getProperty("ChangePasswordPage.NewPassword.Xpath"), argNewPassword);
		return this;
	}
	
	public ChangePasswordPage enterNewPasswordAgain(String argNewPassword){
		enterTextByXpath(prop.getProperty("ChangePasswordPage.NewPasswordAgain.Xpath"), argNewPassword);
		return this;
	}

	public ChangePasswordPage clickChangePassword(){
		clickByXpath(prop.getProperty("ChangePasswordPage.Submit.Xpath"));
		return this;
	}
	
	public ChangePasswordPage clickOK(){
		verifyContentDescIsDisplayed(prop.getProperty("ChangePassword.SuccessMsg.Xpath"));		
		clickByXpath(prop.getProperty("ChangePassword.OKButton.Xpath"));
		return this;
	}
	
/*	public SettingsPage clickBackFromChangePassword(){
		clickByXpath(prop.getProperty("ChangePasswordPage.Back.Xpath"));
		return SettingsPage(driver, test);
	}                                                                                                                                                                
*/}