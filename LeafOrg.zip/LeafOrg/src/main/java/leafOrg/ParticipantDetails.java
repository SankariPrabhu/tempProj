package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class ParticipantDetails extends LeafOrgWrappers {

	public ParticipantDetails(AndroidDriver<?> driver, ExtentTest test) {
		this.driver = driver;
		this.test = test;
	}

}
