package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class SettingsPage extends LeafOrgWrappers{

	public SettingsPage(AndroidDriver<?> driver, ExtentTest test) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		this.test = test;
	}
	
	public EditProfile clickMyProfile(){
		clickByXpath(prop.getProperty("SettingsPage.MyProfile.Xpath"));
		return new EditProfile(driver, test);
	}
	
	public EditParticipantPage clickParticipantDetails(){
		clickByXpath(prop.getProperty("SettingsPage.ParticipantDetails.Xpath"));
		return new EditParticipantPage(driver,test);
	}
	
	public BatchesPage clickBatches(){
		clickByXpath(prop.getProperty("SettingsPage.Batches.Xpath"));
		return new BatchesPage(driver,test);
	}
	

	public ChangePasswordPage clickChangePassword(){
		clickByXpath(prop.getProperty("SettingsPage.ChangePassword.Xpath"));
		return new ChangePasswordPage(driver, test) ;
	}
	
	public SettingsPage clickContactSupport(){
		clickByXpath(prop.getProperty("SettingsPage.ContactSupport.Xpath"));
		return this;
	}
	
	public SettingsPage clickLogout(){
		clickByXpath(prop.getProperty("SettingsPage.Logout.Xpath"));
		return this;
	}
	
	public SettingsPage clickYesLogout(){
		clickByXpath(prop.getProperty("SettingsPage.LogoutYes.Xpath"));
		return this;		
	}
	
	public SettingsPage clickNoLogout(){
		clickByXpath(prop.getProperty("SettingsPage.LogoutYesNo.Xpath"));
		return this;		
	}

}