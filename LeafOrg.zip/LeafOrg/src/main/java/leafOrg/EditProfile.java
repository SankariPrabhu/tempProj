package leafOrg;

import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;
import wrapper.LeafOrgWrappers;

public class EditProfile extends LeafOrgWrappers{
	public EditProfile(AndroidDriver<?> driver, ExtentTest test) {
	
		this.driver = driver;
		this.test = test;
	}

	public EditProfile ModifyFname(String fname){
		enterTextByXpath(prop.getProperty("Editprofile.FirstName.xpath"),fname);
		return this;
	}

	public EditProfile ModifyLname(String lname){
		enterTextByXpath(prop.getProperty("Editprofile.LastName.xpath"), lname);
		return this;
	}
	public EditProfile Modifyphone(String phone){
		enterTextByXpath(prop.getProperty("EditProfile.Phone.xpath"), phone);
		return this;
	}


	public EditProfile clickSavechanges(){
		clickByXpath(prop.getProperty("EditProfile.SaveChanges.xpath"));
		return new EditProfile(driver,test);
		
	}
	public EditProfile VerifyAlertmessage(){
		clickByXpath(prop.getProperty("EditProfile.Alertmessage.xpath"));
		return new EditProfile(driver,test);
	}
	public SettingsPage PressBackbutton(){
		clickByXpath(prop.getProperty("EditProfile.Backbutton.xpath"));
		return new SettingsPage(driver,test);

	}


}