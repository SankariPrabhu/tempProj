package testcases;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import leafOrg.LoginPage;
import leafOrg.SettingsPage;
import wrapper.LeafOrgWrappers;

public class TC02_AddBatch extends LeafOrgWrappers{

	@BeforeClass
	public void setValues(){
		dataSheetName 	= "TC003";
		testCaseName 	= "Login to LeafOrg App";
		testDescription = "Login to LeafOrg app (using POM framework)";
		categories = "smoke";
		authors = "Testleaf";

	}

	@Test(dataProvider="fetchData")
	public void login(String deviceName,String version, String email, String Password, String batchName) throws IOException {

		new LoginPage(driver, test)
		.loginToLeafOrg(deviceName, version, email, Password)
		.clickSettings()
		.clickBatches()
		.clickAddButton()
		.searchBatchInLookup(batchName)
		.selectAppiumMayBatch()
		.clickOkButton()
		.clickBackButton()
		.clickLogout()
		.clickYesLogout();
//		
//		.verifyErrorPopUpMessage()
//		.clickOkErrorPopup()
//		.clickBackButton()
//		.clickLogout()
//		.clickYesLogout();
	}



}
