package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import leafOrg.EditParticipantPage;
import leafOrg.LoginPage;
import wrapper.LeafOrgWrappers;

public class TC04_EditParticipantInfo extends LeafOrgWrappers {
	
	@BeforeClass
	public void setValues(){
		dataSheetName 	= "TC004";
		testCaseName 	= "Edit Participant Info in LeafOrg";
		testDescription = "Edit Participant Info in LeafOrg (using POM framework)";
		categories = "smoke";
		authors = "Testleaf";

	}

	@Test(dataProvider="fetchData")
	public void editParticipantInfo(String deviceName,String version, String email,String Password,String participantId,String mentorName, String text) throws IOException, InterruptedException {
		new LoginPage(driver, test).

		loginToLeafOrg(deviceName, version, email, Password)
		.clickSettings()
		.clickParticipantDetails()
		.editParticipantId(participantId)
		.clickParticipantDate()
		.setParticipantDate()
		.editMentorName(mentorName)
		//.editUrl(url)
		//.editDriverLicense(drivingLicenseId)
		//clickLicenseExpDate()
		//setLicenseExpDate()
		.clickSaveChanges()
		.verifyTextMsg(text)
		.clickAlertMsg()
		.clickBack()
		.clickLogout()
		.clickYesLogout();
		
		
	}



}