package com.AdminConsole.com.AdminConsole;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportLibraries.LoadTestLibraries;
import supportLibraries.ReusableLibraries;

public class NewPdt extends LoadTestLibraries{
//	WebDriver driver;
	WebDriverWait wait=new WebDriverWait(driver,30);
	
	public NewPdt(WebDriver driver){
		ReusableLibraries.driver=driver;
		PageFactory.initElements(driver, this);
		System.out.println("New Pdt Constructor");
	}
	
	@FindBy (xpath="//button[contains(text(),'New Product')]")
	public WebElement btnNewPdt;
	
	@FindBy (name="Name")
	public WebElement uName;
	
	@FindBy (name="ProductCode")
	public WebElement pdtCode;
	
	@FindBy (xpath="//md-select-value[@id='select_value_label_103']/span[@class='md-select-icon']")
	public WebElement family;
	
	@FindBy (xpath="//label[@for='element3']")
	public WebElement active;
	
	@FindBy (id="select_value_label_106")
	public WebElement UOM;
	
	@FindBy (id="select_value_label_111")
	public WebElement Config;
	
	@FindBy (xpath="//input[@placeholder='Effective Date']")
	public WebElement effDate;
	
	@FindBy (linkText ="Save")
	public WebElement saveLink;
	
//	@FindBy (xpath="//button[contains(text(),'New Product')]")
//	public WebElement pdtCode;
	
	public void clickNewProductBtn() throws InterruptedException{
		wait.until(ExpectedConditions.elementToBeClickable(btnNewPdt));
		if (btnNewPdt.isDisplayed()){
			btnNewPdt.click();
			System.out.println("NewPdt Button is clicked");
		}else{
			System.out.println("NewPdt Button is NOT found");
		}
	}
	
	public void enterPdtDetails(String struName,String PdtCode,String strFamily,String strUOM,String strEffDate,String strConfig){
		typeText(uName,struName);  //"Auto-Sankari"
		typeText(pdtCode,PdtCode);
		driver.findElement(By.xpath("//md-select-value[@id='select_value_label_103']/span[@class='md-select-icon']")).click();
//		clickElement(family);
		driver.findElement(By.xpath("//md-option[@value='"+strFamily+"']")).click();
		clickElement(active);
//		selectDropdownByVisibleText(UOM,strUOM);
		clickElement(Config);
		driver.findElement(By.xpath("//md-option[@value='"+strConfig+"']")).click();
		typeText(effDate,strEffDate);
		clickElement(saveLink);
	}
}
