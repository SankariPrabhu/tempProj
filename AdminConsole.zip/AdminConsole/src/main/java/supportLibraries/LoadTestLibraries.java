package supportLibraries;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.relevantcodes.extentreports.ExtentTest;

import supportUtilities.DataInputProvider;

public class LoadTestLibraries extends ReusableLibraries{

	protected String dataSheetName;
	protected String testCaseName;
	protected String testDescription;
	
	@BeforeSuite
	public void beforesuite() throws FileNotFoundException, IOException{
		loadProperty();
		launchApp();
	}
	
//	@BeforeMethod
//	public void beforeMethod(){
//		ExtentTest test = startTestCase(testCaseName,testDescription);
//	}
//	
	@AfterSuite
	public void afterSuite(){
//		endResult();
		driver.close();
	}
//	
//	@AfterMethod
//	public void afterMethod(){
//		endTestcase();
//	}
	
	@DataProvider(name="fetchData")
	public Object[][] getData(){
		return 	DataInputProvider.getSheet(dataSheetName);
	}

}
