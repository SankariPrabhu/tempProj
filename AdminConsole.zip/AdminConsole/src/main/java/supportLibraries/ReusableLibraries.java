package supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import net.sourceforge.htmlunit.corejs.javascript.tools.debugger.Main;
import supportUtilities.Reporter;
import supportUtilities.Wrappers;

public class ReusableLibraries implements Wrappers {
	
	//WebElement Declarations
	
	//Variable Declarations
	public static WebDriver driver;
	Properties prop=new Properties();
	InputStream input=null;
	public String URL="http://windynamics2.apttus.com/cpqjune/admin/ui/app/list";
	
	public void loadProperty() throws FileNotFoundException, IOException{
		prop.load(new FileInputStream (new File("./Config.Properties")));
		if(prop!=null){
			System.out.println("Property File is loaded successfully!!");
		}else{
			System.out.println("Property File is NOT loaded!!");
		}
	}
	
	public void launchApp() {
		// TODO Auto-generated method stub
		String browserPath=prop.getProperty("BrowserPath");
		String url=prop.getProperty("URL");
		System.out.println(browserPath);
		System.out.println(url);
		System.setProperty("webdriver.chrome.driver",browserPath);
		driver=new ChromeDriver();
		driver.get(URL);
		driver.manage().window().maximize();
	}
	
	public void typeText(WebElement elem, String text){
		elem.sendKeys(text);
	 }
	
	public void selectDropdownByVisibleText(WebElement elem, String item){
		Select dropdown=new Select(elem);
		dropdown.selectByVisibleText(item);
	}
	
	public void clickElement(WebElement elem){
		if(elem.isDisplayed()){
			try{
				elem.click();
			}
			catch(NoSuchElementException e){
				System.out.println("Element to be clicked is not found");
			}
		}
	}

}
