package supportUtilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public interface Wrappers {
	public void launchApp();
	public void typeText(WebElement exp, String text);
	public void selectDropdownByVisibleText(WebElement elem, String item);
	public void clickElement(WebElement elem);
}
