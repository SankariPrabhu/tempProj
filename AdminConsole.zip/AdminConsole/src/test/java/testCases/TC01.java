package testCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.AdminConsole.com.AdminConsole.NewPdt;

import supportLibraries.LoadTestLibraries;

public class TC01 extends LoadTestLibraries{

	@BeforeClass
	public void setValues(){
		dataSheetName="NewProduct";
		testCaseName="TC_NewPdt_01";
		testDescription="Enter New Pdt Details";
	}
	@Test(enabled=true)
	public void Test01() throws InterruptedException {
		NewPdt obj= new NewPdt(driver);
		obj.clickNewProductBtn();
	}
	
	@Test(enabled=true , dataProvider="fetchData")
	public void Test02(String TCName,String strName,String PdtCode,String strFamily,String strUOM,String strEffDate,String strConfig){
		NewPdt obj= new NewPdt(driver);
		obj.enterPdtDetails(strName,PdtCode,strFamily,strUOM,strEffDate,strConfig);
	}
	
	
}
